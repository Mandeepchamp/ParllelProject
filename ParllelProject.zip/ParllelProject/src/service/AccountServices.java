package service;

import bean.Account;
import bean.Tansaction;
import dao.AccountDao;

public class AccountServices {
	AccountDao ad = new AccountDao();
	 Tansaction trans;
	public AccountServices (){
		
	}     //Creating Account Method
		public void CreateAccountService(long ac,Account a) {
		
			ad.createAccount(ac,a);
		}
		
		// Showing Account Deatails Method
		public Account showAccountBalance(long ac) {
			Account a = ad.showBalance(ac);
			return a;
		}
		
		//Creating Transaction storage Method 
		public void storeTransaction(long accountNo, Tansaction t) {
		  ad.storeTrasactionDetails(accountNo,t);
		}
		
		//Showing Trancation Details Method
		public Tansaction displayTransaction(long accountNo2) {
		   trans = ad.showTRansaction(accountNo2);
			return trans;
		}

}
